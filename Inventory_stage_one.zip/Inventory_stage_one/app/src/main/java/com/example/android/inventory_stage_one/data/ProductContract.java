package com.example.android.inventory_stage_one.data;

import android.provider.BaseColumns;

public class ProductContract {
    ProductContract() {
        }

    public static final class InventoryEntry implements BaseColumns {
        public final static String TABLE_NAME = "Inventory";
        public final static String _ID = BaseColumns._ID;
        public final static String COLUMN_PRODUCT_NAME = "productname";
        public final static String COLUMN_PRODUCT_PRICE = "productprice";
        public final static String COLUMN_PRODUCT_QUANTITY = "productquantity";
        public final static String COLUMN_PRODUCT_SUPPLIER_NAME = "msuppliername";
        public final static String COLUMN_SUPPLIER_PHONE_NUMBER = "suppliermobile";

        public static final int SUPPLIER_UNKNOWN = 0;
        public static final int SUPPLIER_GROOFERS = 1;
        public static final int SUPPLIER_PAYTM_MALL = 2;
        public static final int SUPPLIER_PHARMEASY = 3;
        }
}
