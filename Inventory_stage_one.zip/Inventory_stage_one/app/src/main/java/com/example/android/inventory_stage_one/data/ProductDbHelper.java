package com.example.android.inventory_stage_one.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.android.inventory_stage_one.data.ProductContract.InventoryEntry;

public class ProductDbHelper extends SQLiteOpenHelper {
    public static final String LOG_TAG = ProductDbHelper.class.getSimpleName();
    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    public ProductDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase data) {
        String SQL_CREATE_PRODUCT_TABLE = "CREATE TABLE " + InventoryEntry.TABLE_NAME + " (" + InventoryEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + InventoryEntry.COLUMN_PRODUCT_NAME + " TEXT NOT NULL, " + InventoryEntry.COLUMN_PRODUCT_PRICE + " INTEGER NOT NULL, " + InventoryEntry.COLUMN_PRODUCT_QUANTITY + " INTEGER NOT NULL, " + InventoryEntry.COLUMN_PRODUCT_SUPPLIER_NAME + " INTEGER NOT NULL DEFAULT 0, " + InventoryEntry.COLUMN_SUPPLIER_PHONE_NUMBER + " INTEGER );";
        data.execSQL(SQL_CREATE_PRODUCT_TABLE);
        Log.d("successfully message", "created table of data");
        }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        }
}
