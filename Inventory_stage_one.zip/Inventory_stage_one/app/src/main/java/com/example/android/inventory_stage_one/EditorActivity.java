package com.example.android.inventory_stage_one;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.android.inventory_stage_one.data.ProductContract;
import com.example.android.inventory_stage_one.data.ProductDbHelper;

import static com.example.android.inventory_stage_one.data.ProductContract.*;
import static com.example.android.inventory_stage_one.data.ProductContract.InventoryEntry.SUPPLIER_UNKNOWN;

public class EditorActivity extends AppCompatActivity {
    private EditText mproductname;
    private EditText mproductprice;
    private EditText mproductquantity;
    private EditText msupplierphone;
    private Spinner mspinnersuppliername;

    private int msuppliername = SUPPLIER_UNKNOWN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        mproductname = (EditText) findViewById(R.id.edit_text_name);
        mproductprice = (EditText) findViewById(R.id.edit_price);
        mproductquantity = (EditText) findViewById(R.id.edit_quantity);
        mspinnersuppliername = findViewById(R.id.spinner_name);
        msupplierphone = (EditText) findViewById(R.id.mobileno);
        setupSpinner();
    }

    private void setupSpinner() {
        ArrayAdapter productSupplieNameSpinnerAdapter = ArrayAdapter.createFromResource(this, R.array.options_supplier_name, android.R.layout.simple_spinner_item);

        productSupplieNameSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        mspinnersuppliername.setAdapter(productSupplieNameSpinnerAdapter);

        mspinnersuppliername.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selection = (String) parent.getItemAtPosition(position);
                if (!TextUtils.isEmpty(selection)) {
                    if (selection.equals(getString(R.string.supplier_first))) {
                        msuppliername = InventoryEntry.SUPPLIER_GROOFERS;
                    } else if (selection.equals(getString(R.string.supplier_second))) {
                        msuppliername = InventoryEntry.SUPPLIER_PAYTM_MALL;
                    } else if (selection.equals(getString(R.string.supplier_third))) {
                        msuppliername = InventoryEntry.SUPPLIER_PHARMEASY;
                    } else {
                        msuppliername = InventoryEntry.SUPPLIER_UNKNOWN;
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                msuppliername = InventoryEntry.SUPPLIER_UNKNOWN;
            }
        });
    }

    private void insertProduct() {
        String productName = mproductname.getText().toString().trim();

        String productPrice = mproductprice.getText().toString().trim();
        int productPriceInt = Integer.parseInt(productPrice);

        String productQuantity = mproductquantity.getText().toString().trim();
        int productQuantityInt = Integer.parseInt(productQuantity);

        String productSupplierPhoneNumber = msupplierphone.getText().toString().trim();
        int productSupplierPhoneNumberInt = Integer.parseInt(productSupplierPhoneNumber);

        ProductDbHelper mDbHelper = new ProductDbHelper(this);
        SQLiteDatabase db = mDbHelper.getWritableDatabase();


        ContentValues values = new ContentValues();
        values.put(InventoryEntry.COLUMN_PRODUCT_NAME, productName);
        values.put(InventoryEntry.COLUMN_PRODUCT_PRICE, productPriceInt);
        values.put(InventoryEntry.COLUMN_PRODUCT_QUANTITY, productQuantityInt);
        values.put(InventoryEntry.COLUMN_PRODUCT_SUPPLIER_NAME, msuppliername);
        values.put(InventoryEntry.COLUMN_SUPPLIER_PHONE_NUMBER, productSupplierPhoneNumberInt);

        long newRowId = db.insert(InventoryEntry.TABLE_NAME, null, values);

        if (newRowId == -1) {
            Toast.makeText(this, "Error with saving product", Toast.LENGTH_SHORT).show();


        } else {
            Toast.makeText(this, "Product saved with row id: " + newRowId, Toast.LENGTH_SHORT).show();

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_editor, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.action_save:
                insertProduct();
                finish();
                return true;
            case android.R.id.home:
                NavUtils.navigateUpFromSameTask(this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
